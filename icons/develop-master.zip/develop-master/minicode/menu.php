 


<p><a href="index.php">My Profile</a> | <a href="full-list.php">All Tasks</a> |
 <a href="full-list.php?new_page=1">Add a new page!</a> | <a href="full-list.php?to_do=1">New TO DO!</a>
| <a href="logout.php">Logout</a></p>
<hr/>
 

 
