<li style="background-color:#FF9900" id="li_changeto_active" onClick="change_status('li_changeto_active',1 )">Active</li>
<li style="background-color:#000" id="li_changeto_completed" onClick="change_status('li_changeto_completed',2 )">Completed</li>
<li style="background-color:#CCC" id="li_changeto_cancelled" onClick="change_status('li_changeto_cancelled',3 )">Cancelled</li>