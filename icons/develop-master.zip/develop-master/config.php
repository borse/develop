<?php
	define('DB_HOST', 'localhost');
    define('DB_USER', '1116075_db');
    define('DB_PASSWORD', 'SIlver');
    define('DB_DATABASE', 'db_develop');
?>